# Finally, the file /envs/__init__.py should include the instruction for importing the environment:
from balance_bot.envs.balancebot_env import BalancebotEnv
